/*
 * miun_lab2.h
 *
 *  Created on: 27 jun 2011
 *      Author: markus
 */

#ifndef MIUN_LAB2_H_
#define MIUN_LAB2_H_
#include "Person.h"

int main();
int getChoice();
void printMenu();
void printPersons(std::Person *obj);
void setPerson(std::Person *person);

#endif /* MIUN_LAB2_H_ */
